//
//  TiCardscanner.h
//  ti.cardscanner
//
//  Created by Marc Bender
//  Copyright (c) 2022 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiCardscanner.
FOUNDATION_EXPORT double TiCardscannerVersionNumber;

//! Project version string for TiCardscanner.
FOUNDATION_EXPORT const unsigned char TiCardscannerVersionString[];

#import "TiCardscannerModuleAssets.h"
